package edu.ncsu.mavenbot.test;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
