package edu.ncsu.mavenbot.adapters;

public class FileUtils {
	public static boolean copyDir(String src, String dest){
		
		return false;
	}
}
